﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


 //Al presionar el boton mover se empezara a mover la imagen de izquierda a derecha,
 //hasta tocar cada esquina y devolverse 
 //
namespace colicion
{
    public partial class Form1 : Form
    {

        private Timer timer;
        private PictureBox imageBox;
        private int imageSpeed = 5;
        private int imageDirection = 1;
        private bool isMoving = false; 

        public Form1()
        {
            InitializeComponent();
            InitializeImage();
            InitializeTimer();
        }

        private void InitializeImage()
        {
            imageBox = new PictureBox
            {
                Image = Properties.Resources.images1, 
                SizeMode = PictureBoxSizeMode.StretchImage,
                Location = new Point(100, 100), 
                Size = new Size(100, 100) 
            };
            Controls.Add(imageBox);
        }

        private void InitializeTimer()
        {
            timer = new Timer { Interval = 20 }; 
            timer.Tick += Timer_Tick; 
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {

            if (isMoving)
            {
                
                imageBox.Left += imageSpeed * imageDirection;

                
                if (imageBox.Left <= 0 || imageBox.Right >= ClientSize.Width)
                {
                    
                    imageDirection *= -1;
                }
            }

        }
        private void btnMover_Click_1(object sender, EventArgs e)
        {
            isMoving = !isMoving;
        }

        private void btnDetener_Click(object sender, EventArgs e)
        {
            isMoving = false;
        }
    }
}
